# Browserify example

Two steps need to be done for this to work

In the project root

    npm install

In this folder

    ../../node_modules/.bin/browserify main.js -o bundle.js
