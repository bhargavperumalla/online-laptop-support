﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Attendance.Model
{
   public class AnniversaryDto
    {
        public string SlackId { get; set; }

        public string FirstName { get; set; }

        public int ISDOA { get; set; }

        public int ISDOB { get; set; }

        public int ISDOJ { get; set; }
    }
}
