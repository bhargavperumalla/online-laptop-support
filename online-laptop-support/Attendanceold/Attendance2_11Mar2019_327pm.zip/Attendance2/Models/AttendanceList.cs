﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Attendance.Models
{
    public class AttendanceList
    {
       public List<Attendance> values { get; set; }
    }
}