﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Attendance.Models
{
    public class Dashboard
    {
        public string employeeName { get; set; }
        public string duration { get; set; }
        public string present { get; set; }
        public string leaves { get; set; }
        public string COFF { get; set; }

    }
}