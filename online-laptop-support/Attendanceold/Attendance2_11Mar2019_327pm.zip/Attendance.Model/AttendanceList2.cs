﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Attendance.Model
{
  public class AttendanceList2
    {
        public List<AttendanceDto> values { get; set; }
    }
}
